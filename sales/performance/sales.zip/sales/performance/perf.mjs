var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { transformEntries as abapTransformEntries } from "../dist/abap-transformation-executor.mjs";
export function performTransformation(transformationId, entries) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log(`Executing performance testing of ${entries.length} entries using transformation with id ${transformationId}`);
        const startTime = Date.now();
        const transformedEntries = yield abapTransformEntries(transformationId, entries);
        const endTime = Date.now();
        const transformationMillis = (endTime - startTime);
        console.log(`Transformation of ${entries.length} entries to ${transformedEntries.length} using transformation ${transformationId} took ${transformationMillis}ms`);
    });
}
